#!/bin/bash

echo "=========================================="
echo "Workstation AI Agent - Quick Install"
echo "=========================================="
echo ""

# Check if running on macOS or Linux
if [[ "$OSTYPE" == "darwin"* ]]; then
    CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    CHROME_EXTENSIONS="chrome://extensions/"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    CHROME_PATH="google-chrome"
    CHROME_EXTENSIONS="chrome://extensions/"
else
    echo "❌ Unsupported operating system"
    exit 1
fi

echo "📋 Installation Steps:"
echo ""
echo "1. This script will open Chrome extensions page"
echo "2. Enable 'Developer mode' (toggle in top-right)"
echo "3. Click 'Load unpacked'"
echo "4. Select this folder: $(pwd)"
echo ""
read -p "Press Enter to open Chrome..."

# Open Chrome extensions page
if command -v xdg-open &> /dev/null; then
    xdg-open "$CHROME_EXTENSIONS"
elif command -v open &> /dev/null; then
    open "$CHROME_EXTENSIONS"
else
    echo "Please manually open: $CHROME_EXTENSIONS"
fi

echo ""
echo "✅ Follow the instructions in Chrome to complete installation"
echo ""
